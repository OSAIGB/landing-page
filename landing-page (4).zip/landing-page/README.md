# Landing Page Project

#This landing page dynamically scroll through each section to give users the ease of accessing each section with ease and beauty.